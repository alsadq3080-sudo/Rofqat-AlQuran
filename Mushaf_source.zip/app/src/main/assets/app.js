(function () {
'use strict';

/* ================= البيانات الثابتة ================= */
var SURAHS = ['الفاتحة','البقرة','آل عمران','النساء','المائدة','الأنعام','الأعراف','الأنفال','التوبة','يونس',
'هود','يوسف','الرعد','إبراهيم','الحجر','النحل','الإسراء','الكهف','مريم','طه',
'الأنبياء','الحج','المؤمنون','النور','الفرقان','الشعراء','النمل','القصص','العنكبوت','الروم',
'لقمان','السجدة','الأحزاب','سبأ','فاطر','يس','الصافات','ص','الزمر','غافر',
'فصلت','الشورى','الزخرف','الدخان','الجاثية','الأحقاف','محمد','الفتح','الحجرات','ق',
'الذاريات','الطور','النجم','القمر','الرحمن','الواقعة','الحديد','المجادلة','الحشر','الممتحنة',
'الصف','الجمعة','المنافقون','التغابن','الطلاق','التحريم','الملك','القلم','الحاقة','المعارج',
'نوح','الجن','المزمل','المدثر','القيامة','الإنسان','المرسلات','النبأ','النازعات','عبس',
'التكوير','الانفطار','المطففين','الانشقاق','البروج','الطارق','الأعلى','الغاشية','الفجر','البلد',
'الشمس','الليل','الضحى','الشرح','التين','العلق','القدر','البينة','الزلزلة','العاديات',
'القارعة','التكاثر','العصر','الهمزة','الفيل','قريش','الماعون','الكوثر','الكافرون','النصر',
'المسد','الإخلاص','الفلق','الناس'];

var ICON = {
  list:'<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
  search:'<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  bookmark:'<path d="M6 4h12v17l-6-4-6 4z"/>',
  info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
  chev:'<path d="M15 6l-6 6 6 6"/>',
  back:'<path d="M5 12h14M13 6l6 6-6 6"/>',
  copy:'<rect x="9" y="9" width="11" height="11" rx="2.5"/><path d="M5 15V6.5A2.5 2.5 0 0 1 7.5 4H16"/>',
  send:'<path d="M4 12L20 4l-6 16-3-7z"/>',
  image:'<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="1.6"/><path d="M21 16l-5-5-8 8"/>',
  x:'<path d="M6 6l12 12M18 6L6 18"/>',
  download:'<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
  book:'<path d="M4 5.5C7 4 10 4.3 12 6c2-1.7 5-2 8-.5V19c-3-1.5-6-1.2-8 .5-2-1.7-5-2-8-.5z"/><path d="M12 6v13.5"/>',
  moon:'<path d="M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z"/>',
  prev:'<path d="M9 6l6 6-6 6"/>',
  play:'<path d="M8 5l11 7-11 7z"/>',
  pause:'<path d="M8 5v14M16 5v14"/>',
  skipb:'<path d="M18 5L9 12l9 7zM6 5v14"/>',
  skipf:'<path d="M6 5l9 7-9 7zM18 5v14"/>',
  trash:'<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  check:'<path d="M5 12l5 5 9-10"/>',
  headphones:'<path d="M4 15v-3a8 8 0 0 1 16 0v3M4 15a2 2 0 0 0 2 2h1v-5H6a2 2 0 0 0-2 2zM20 15a2 2 0 0 1-2 2h-1v-5h1a2 2 0 0 1 2 2z"/>'
};
function ic(n, s, fill) {
  return '<svg class="ic" aria-hidden="true" width="' + (s || 24) + '" height="' + (s || 24) +
    '" viewBox="0 0 24 24" fill="' + (fill || 'none') + '" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' +
    ICON[n] + '</svg>';
}

/* ================= أدوات ================= */
function AR(n) { return String(n).replace(/\d/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'[d]; }); }
function $(s, r) { return (r || document).querySelector(s); }
function esc(s) {
  return String(s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
function ayahWord(n) { return (n >= 3 && n <= 10) ? 'آيات' : 'آية'; }
var store = {
  get: function (k, d) {
    try { var v = localStorage.getItem('mushaf.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; }
  },
  set: function (k, v) { try { localStorage.setItem('mushaf.' + k, JSON.stringify(v)); } catch (e) {} }
};
function norm(s) {
  return s
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g, '')
    .replace(/[\u0622\u0623\u0625\u0671]/g, '\u0627')
    .replace(/\u0649/g, '\u064A').replace(/\u06CC/g, '\u064A')
    .replace(/\u0629/g, '\u0647')
    .replace(/\u0624/g, '\u0648').replace(/\u0626/g, '\u064A')
    .replace(/\u0621/g, '');
}

/* ================= الحالة ================= */
var AY = [];          // AY[s] = نصوص آيات السورة s (كما هي في الملف)
var FLAT = [];        // {s,a,n} لكل آية بالترتيب (للبحث)
var OFFSET = [];      // OFFSET[s] = ترتيب أول آية في السورة داخل المصحف
var META = null;      // {tafsir,page,juz}
var BASM = '';
var BASM_N = '';
var state = { tab: 'home', surah: 0, sel: 0, fs: store.get('fs', 30), theme: store.get('theme', 'night') };
var shareState = null;

/* ================= التحميل ================= */
function parse(txt) {
  var lines = txt.split('\n'), re = /^(\d+)\|(\d+)\|(.+)$/, total = 0, m, s, a;
  for (var i = 0; i < lines.length; i++) {
    m = re.exec(lines[i].replace(/\r$/, ''));
    if (!m) continue;
    s = +m[1]; a = +m[2];
    if (!AY[s]) AY[s] = [];
    AY[s][a - 1] = m[3];
    total++;
  }
  var ok = total === 6236 && AY.length === 115;
  if (ok) {
    for (s = 1; s <= 114; s++) for (a = 0; a < AY[s].length; a++) if (typeof AY[s][a] !== 'string') ok = false;
  }
  if (!ok) throw new Error('quran.txt incomplete: ' + total);
  BASM = AY[1][0];
  BASM_N = norm(BASM);
  var idx = 0;
  for (s = 1; s <= 114; s++) {
    OFFSET[s] = idx;
    for (a = 1; a <= AY[s].length; a++) {
      FLAT.push({ s: s, a: a, n: norm(ayahText(s, a)) });
      idx++;
    }
  }
}
function load() {
  return fetch('quran.txt').then(function (r) { return r.text(); }).then(parse)
    .then(function () {
      return fetch('meta.json').then(function (r) { return r.json(); })
        .then(function (m) { META = m; }).catch(function () { META = null; });
    });
}

/* نص الآية للعرض: البسملة التي تسبق الآية الأولى في الملف تُعرض كعنوان منفصل */
function ayahText(s, a) {
  var t = AY[s][a - 1];
  if (a === 1 && s !== 1 && s !== 9) {
    var words = t.split(' ');
    if (words.length > 4 && norm(words.slice(0, 4).join(' ')) === BASM_N) return words.slice(4).join(' ');
  }
  return t;
}
function flatIndex(s, a) { return OFFSET[s] + a - 1; }
function refName(s, a) { return 'سورة ' + SURAHS[s - 1] + '، الآية ' + AR(a); }
function shareTextOf(s, a) {
  return '\uFD3F' + ayahText(s, a) + '\uFD3E\n[سورة ' + SURAHS[s - 1] + ': ' + AR(a) + ']';
}

/* ================= الواجهة: الشاشات الرئيسية ================= */
function star(n) {
  return '<div class="star"><svg width="46" height="46" viewBox="0 0 46 46" aria-hidden="true">' +
    '<rect x="9" y="9" width="28" height="28" rx="4" fill="rgba(227,191,115,.08)" stroke="rgba(227,191,115,.7)" stroke-width="1.2"/>' +
    '<rect x="9" y="9" width="28" height="28" rx="4" fill="none" stroke="rgba(227,191,115,.7)" stroke-width="1.2" transform="rotate(45 23 23)"/></svg>' +
    '<span>' + AR(n) + '</span></div>';
}
function renderTabs() {
  var items = [['home', 'list', 'السور'], ['search', 'search', 'البحث'], ['audio', 'headphones', 'الصوت'], ['saved', 'bookmark', 'المحفوظات']];
  var btns = document.querySelectorAll('#tabbar .tab');
  for (var i = 0; i < btns.length; i++) {
    btns[i].innerHTML = ic(items[i][1], 24) + '<span>' + items[i][2] + '</span>';
    if (items[i][0] === state.tab) btns[i].setAttribute('aria-current', 'page');
    else btns[i].removeAttribute('aria-current');
  }
}
function renderHome() {
  var last = store.get('last', { s: 1, a: 1 });
  if (!AY[last.s] || !AY[last.s][last.a - 1]) last = { s: 1, a: 1 };
  var rows = '';
  for (var s = 1; s <= 114; s++) {
    var c = AY[s].length;
    rows += '<button type="button" class="row lite" data-act="open" data-s="' + s + '">' + star(s) +
      '<div class="grow"><div class="nm">سورة ' + SURAHS[s - 1] + '</div><div class="ct">' + AR(c) + ' ' + ayahWord(c) + '</div></div>' +
      ic('chev', 22) + '</button>';
  }
  $('#home').innerHTML =
    '<header class="top"><div><h1 class="title">المصحف</h1><p class="sub-title">رواية حفص عن عاصم</p></div>' +
    '<button type="button" class="ibtn glass" data-act="about" aria-label="عن التطبيق">' + ic('info', 24) + '</button></header>' +
    '<section class="hero glass"><div class="meta"><span class="lbl">تابع القراءة</span><span class="sub" style="font-size:13px">' +
    SURAHS[last.s - 1] + '، الآية ' + AR(last.a) + '</span></div>' +
    '<p>' + esc(ayahText(last.s, last.a)) + '</p>' +
    '<button type="button" class="btn-gold" data-act="open" data-s="' + last.s + '" data-a="' + last.a + '">أكمل القراءة ' + ic('back', 20) + '</button></section>' +
    '<button type="button" class="search-box lite" style="width:100%;text-align:start" data-act="tab" data-tab="search">' + ic('search', 22) +
    '<span>ابحث في آيات القرآن</span></button>' +
    '<div class="list">' + rows + '</div>';
}
var searchTimer = null;
function renderSearch() {
  $('#search').innerHTML =
    '<h2>البحث</h2><label class="search-box lite">' + ic('search', 22) +
    '<input id="q" type="search" autocomplete="off" placeholder="اكتب كلمة أو جزءًا من آية" aria-label="ابحث في آيات القرآن"></label>' +
    '<div id="results"></div>';
  $('#results').innerHTML = '<p class="empty">اكتب كلمتين أو أكثر من الآية، أو كلمة واحدة على الأقل من حرفين.</p>';
}
function doSearch(q) {
  var box = $('#results');
  var nq = norm(q.trim());
  if (nq.length < 2) { box.innerHTML = '<p class="empty">اكتب كلمتين أو أكثر من الآية، أو كلمة واحدة على الأقل من حرفين.</p>'; return; }
  var out = [], total = 0, i, f;
  for (i = 0; i < FLAT.length; i++) {
    f = FLAT[i];
    if (f.n.indexOf(nq) !== -1) { total++; if (out.length < 60) out.push(f); }
  }
  if (!total) { box.innerHTML = '<p class="empty">لا توجد نتائج. جرّب كلمة أقصر أو بدون تشكيل.</p>'; return; }
  var h = '<div class="count">' + AR(total) + ' نتيجة' + (total > 60 ? ' — أول ٦٠ نتيجة' : '') + '</div><div class="list">';
  out.forEach(function (r) {
    h += '<button type="button" class="row lite" data-act="open" data-pick="1" data-s="' + r.s + '" data-a="' + r.a + '">' +
      '<div class="grow"><div class="ct">' + SURAHS[r.s - 1] + '، الآية ' + AR(r.a) + '</div>' +
      '<div class="snip">' + esc(ayahText(r.s, r.a)) + '</div></div>' + ic('chev', 22) + '</button>';
  });
  box.innerHTML = h + '</div>';
}
function bookmarks() { return store.get('bm', []); }
function isBm(s, a) { return bookmarks().indexOf(s + ':' + a) !== -1; }
function renderSaved() {
  var bm = bookmarks(), h = '<h2>المحفوظات</h2>';
  if (!bm.length) {
    h += '<p class="empty">لم تحفظ أي آية بعد.<br>اضغط على أي آية أثناء القراءة، ثم اختر «حفظ».</p>';
  } else {
    h += '<div class="list">';
    bm.forEach(function (k) {
      var p = k.split(':'), s = +p[0], a = +p[1];
      h += '<button type="button" class="row lite" data-act="open" data-pick="1" data-s="' + s + '" data-a="' + a + '">' +
        '<div class="grow"><div class="ct">' + SURAHS[s - 1] + '، الآية ' + AR(a) + '</div>' +
        '<div class="snip">' + esc(ayahText(s, a)) + '</div></div>' + ic('chev', 22) + '</button>';
    });
    h += '</div>';
  }
  $('#saved').innerHTML = h;
}
function showTab(t) {
  state.tab = t;
  ['home', 'search', 'saved', 'audio'].forEach(function (k) { $('#' + k).hidden = (k !== t); });
  if (t === 'home') renderHome();
  if (t === 'search') { renderSearch(); }
  if (t === 'saved') renderSaved();
  if (t === 'audio') renderAudio();
  renderTabs();
}

/* ================= القارئ ================= */
var scrollTimer = null;
function openReader(s, a, pick) {
  state.surah = s; state.sel = 0;
  var n = AY[s].length, h = '', i;
  var showBasm = (s !== 1 && s !== 9);
  var spans = '';
  for (i = 1; i <= n; i++) {
    spans += '<span class="ay" data-a="' + i + '">' + esc(ayahText(s, i)) + '<span class="num">' + AR(i) + '</span></span> ';
  }
  h += '<header class="rhead glass"><button type="button" class="ibtn lite" data-act="close" aria-label="رجوع">' + ic('back', 24) + '</button>' +
    '<div class="rtitle"><h2>سورة ' + SURAHS[s - 1] + '</h2><p>' + AR(n) + ' ' + ayahWord(n) + '</p></div>' +
    '<button type="button" class="ibtn lite" data-act="aa" aria-label="حجم الخط والمظهر" style="font-size:17px;font-weight:600">Aa</button></header>' +
    '<div class="rbody" id="rbody">' + (showBasm ? '<div class="basm">' + esc(BASM) + '</div>' : '') +
    '<p class="mus" id="mus">' + spans + '</p><div class="rnav">' +
    (s < 114 ? '<button type="button" class="lite" data-act="nav" data-s="' + (s + 1) + '">السورة التالية</button>' : '') +
    (s > 1 ? '<button type="button" class="lite" data-act="nav" data-s="' + (s - 1) + '">السورة السابقة</button>' : '') +
    '</div></div><div class="aa glass" id="aa" hidden>' +
    '<div class="rowx"><button type="button" class="sm lite" data-act="fs" data-d="-2" aria-label="تصغير الخط">أ−</button>' +
    '<span id="fsv">' + AR(state.fs) + '</span><button type="button" class="sm lite" data-act="fs" data-d="2" aria-label="تكبير الخط">أ+</button></div>' +
    '<div class="rowx"><button type="button" class="wide lite" data-act="theme">' + ic('moon', 20) + '<span id="thl"></span></button></div></div>';
  var r = $('#reader');
  r.innerHTML = h;
  applyFs();
  updateThemeLabel();
  r.classList.add('open'); r.setAttribute('aria-hidden', 'false');
  document.body.classList.add('in-reader');
  var body = $('#rbody');
  body.addEventListener('scroll', onReaderScroll, { passive: true });
  closeSheet();
  markPlaying();
  store.set('last', { s: s, a: a || 1 });
  if (a && a > 1) {
    setTimeout(function () {
      var el = $('.ay[data-a="' + a + '"]');
      if (el) { el.scrollIntoView({ block: 'center' }); if (pick) selectAyah(a); }
    }, 60);
  } else {
    body.scrollTop = 0;
  }
}
function closeReader() {
  var r = $('#reader');
  r.classList.remove('open'); r.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('in-reader');
  closeSheet(); state.surah = 0;
  if (state.tab === 'home') renderHome();
  if (state.tab === 'saved') renderSaved();
}
function onReaderScroll() {
  clearTimeout(scrollTimer);
  scrollTimer = setTimeout(function () {
    var top = 90, els = document.querySelectorAll('#mus .ay'), i, rc;
    for (i = 0; i < els.length; i++) {
      rc = els[i].getBoundingClientRect();
      if (rc.bottom > top + 12) { store.set('last', { s: state.surah, a: +els[i].getAttribute('data-a') }); return; }
    }
  }, 500);
}
function applyFs() {
  var fs = Math.max(22, Math.min(46, state.fs));
  state.fs = fs; store.set('fs', fs);
  $('#reader').style.setProperty('--fs', fs + 'px');
  var v = $('#fsv'); if (v) v.textContent = AR(fs);
}
function updateThemeLabel() {
  var l = $('#thl'); if (l) l.textContent = state.theme === 'night' ? 'التبديل إلى مظهر الورق' : 'التبديل إلى المظهر الليلي';
}
function setTheme(t) {
  state.theme = t; store.set('theme', t);
  document.body.setAttribute('data-theme', t);
  if (window.Android && Android.setBars) Android.setBars(t === 'paper');
  updateThemeLabel();
}

/* ================= قائمة خيارات الآية ================= */
function selectAyah(a) {
  var prev = $('#mus .ay.sel'); if (prev) prev.classList.remove('sel');
  var el = $('#mus .ay[data-a="' + a + '"]'); if (!el) return;
  el.classList.add('sel');
  state.sel = a;
  store.set('last', { s: state.surah, a: a });
  renderSheet();
  setTimeout(function () {
    var sh = $('#sheet'), rc = el.getBoundingClientRect(), lim = window.innerHeight - sh.offsetHeight - 24;
    if (rc.bottom > lim) $('#rbody').scrollTop += rc.bottom - lim;
  }, 30);
}
function renderSheet() {
  var s = state.surah, a = state.sel, sh = $('#sheet');
  var on = isBm(s, a), fi = flatIndex(s, a), meta = '';
  if (META) meta = 'الجزء ' + AR(META.juz[fi]) + ' · صفحة ' + AR(META.page[fi]);
  function act(name, icon, label, cls, extra) {
    return '<button type="button" class="act' + (extra || '') + '" data-act="' + name + '"><span class="tile ' + (cls || 'lite') + '">' + ic(icon, 24, cls === 'on lite' ? 'currentColor' : 'none') + '</span><span class="t">' + label + '</span></button>';
  }
  sh.innerHTML = '<div class="grab"></div><div class="shead"><div><b>' + SURAHS[s - 1] + '، الآية ' + AR(a) + '</b>' + (meta ? '<small>' + meta + '</small>' : '') + '</div>' +
    '<button type="button" class="xbtn" data-act="closesheet" aria-label="إغلاق">' + ic('x', 22) + '</button></div>' +
    '<button type="button" class="listen" data-act="listen">' + ic('play', 20, 'currentColor') + 'استمع من هنا</button><div class="acts">' + act('copy', 'copy', 'نسخ') + act('sharetext', 'send', 'مشاركة نص') +
    act('shareimg', 'image', 'مشاركة صورة', 'hot') + act('bm', 'bookmark', on ? 'محفوظة' : 'حفظ', on ? 'on lite' : 'lite') +
    act('tafsir', 'book', 'تفسير') + '</div>';
  sh.hidden = false;
}
function closeSheet() {
  var sh = $('#sheet'); sh.hidden = true;
  var prev = $('#mus .ay.sel'); if (prev) prev.classList.remove('sel');
  state.sel = 0;
}
function showTafsir() {
  var s = state.surah, a = state.sel, sh = $('#sheet');
  if (!META) { toast('التفسير غير متوفر'); return; }
  var t = META.tafsir[flatIndex(s, a)] || '';
  sh.innerHTML = '<div class="grab"></div><div class="shead"><div><b>التفسير</b><small>' + SURAHS[s - 1] + '، الآية ' + AR(a) + '</small></div>' +
    '<button type="button" class="xbtn" data-act="tback" aria-label="رجوع">' + ic('x', 22) + '</button></div>' +
    '<div class="tafsir"><div class="ayx">' + esc(ayahText(s, a)) + '</div>' + esc(t) + '</div>';
}
function toggleBm() {
  var s = state.surah, a = state.sel, key = s + ':' + a, bm = bookmarks(), i = bm.indexOf(key);
  if (i === -1) { bm.unshift(key); toast('تم حفظ الآية'); } else { bm.splice(i, 1); toast('أُزيلت من المحفوظات'); }
  store.set('bm', bm);
  renderSheet();
  var b = $('#sheet [data-act="bm"]'); if (b) b.classList.add('pop');
}

/* ================= مشاركة كصورة ================= */
var QFONT = "'QuranFont','Noto Naskh Arabic','Droid Naskh Shift','Amiri',serif";
var UFONT = "'IBM Plex Sans Arabic','Noto Sans Arabic','Roboto',sans-serif";
var STYLES = {
  night: { bg: ['#051315', '#0B3A36', '#134E45'], orbs: [[.85, .08, .55, 60, 190, 165, .45], [.1, .8, .5, 227, 191, 115, .22]],
    text: '#F6F1E4', accent: '#E3BF73', card: ['rgba(255,255,255,.17)', 'rgba(255,255,255,.05)'], border: 'rgba(255,255,255,.26)', dot: 'linear-gradient(135deg,#0B3A36,#134E45)' },
  dawn: { bg: ['#FBE8CC', '#F4B8A2', '#A9709B'], orbs: [[.85, .1, .5, 255, 255, 255, .5], [.1, .85, .5, 255, 214, 150, .45]],
    text: '#2A1830', accent: '#6B3B1E', card: ['rgba(255,255,255,.5)', 'rgba(255,255,255,.22)'], border: 'rgba(255,255,255,.7)', dot: 'linear-gradient(135deg,#F4B8A2,#A9709B)' },
  paper: { bg: ['#F6F1E4', '#EADFC6', '#DCCFAE'], orbs: [[.85, .1, .5, 255, 255, 255, .7], [.1, .85, .5, 154, 117, 34, .18]],
    text: '#16302B', accent: '#8A6A1E', card: ['rgba(255,255,255,.6)', 'rgba(255,255,255,.3)'], border: 'rgba(154,117,34,.35)', dot: 'linear-gradient(135deg,#F6F1E4,#DCCFAE)' }
};
function rr(c, x, y, w, h, r) {
  c.beginPath(); c.moveTo(x + r, y); c.lineTo(x + w - r, y); c.quadraticCurveTo(x + w, y, x + w, y + r);
  c.lineTo(x + w, y + h - r); c.quadraticCurveTo(x + w, y + h, x + w - r, y + h); c.lineTo(x + r, y + h);
  c.quadraticCurveTo(x, y + h, x, y + h - r); c.lineTo(x, y + r); c.quadraticCurveTo(x, y, x + r, y); c.closePath();
}
function wrap(c, text, maxW) {
  var words = text.split(' '), lines = [], line = '', i, test;
  for (i = 0; i < words.length; i++) {
    test = line ? line + ' ' + words[i] : words[i];
    if (c.measureText(test).width > maxW && line) { lines.push(line); line = words[i]; } else { line = test; }
  }
  if (line) lines.push(line);
  return lines;
}
function drawCard(cv, text, ref, styleKey, fmt) {
  var st = STYLES[styleKey], W = 1080, H = fmt === 'story' ? 1920 : 1080;
  cv.width = W; cv.height = H;
  var c = cv.getContext('2d');
  var g = c.createLinearGradient(0, 0, W * 0.4, H);
  g.addColorStop(0, st.bg[0]); g.addColorStop(.55, st.bg[1]); g.addColorStop(1, st.bg[2]);
  c.fillStyle = g; c.fillRect(0, 0, W, H);
  st.orbs.forEach(function (o) {
    var x = o[0] * W, y = o[1] * H, r = o[2] * Math.max(W, H), col = o[3] + ',' + o[4] + ',' + o[5];
    var rg = c.createRadialGradient(x, y, 0, x, y, r);
    rg.addColorStop(0, 'rgba(' + col + ',' + o[6] + ')'); rg.addColorStop(1, 'rgba(' + col + ',0)');
    c.fillStyle = rg; c.fillRect(0, 0, W, H);
  });
  var cx = 70, cw = 940, top = fmt === 'story' ? 330 : 80, ch = fmt === 'story' ? 1200 : 920, bottom = top + ch;
  var cg = c.createLinearGradient(cx, top, cx + cw, bottom);
  cg.addColorStop(0, st.card[0]); cg.addColorStop(1, st.card[1]);
  rr(c, cx, top, cw, ch, 56); c.fillStyle = cg; c.fill();
  c.lineWidth = 2.5; c.strokeStyle = st.border; c.stroke();
  // زخرفة
  var ox = W / 2, oy = top + 88;
  c.strokeStyle = st.accent; c.lineWidth = 3; c.lineCap = 'round';
  c.beginPath(); c.moveTo(ox - 270, oy); c.lineTo(ox - 60, oy); c.moveTo(ox + 60, oy); c.lineTo(ox + 270, oy); c.stroke();
  c.save(); c.translate(ox, oy); c.strokeRect(-22, -22, 44, 44); c.rotate(Math.PI / 4); c.strokeRect(-22, -22, 44, 44); c.restore();
  // النص
  var areaTop = top + 170, areaBottom = bottom - 150, maxH = areaBottom - areaTop, maxW = cw - 150;
  c.direction = 'rtl'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = st.text;
  var size, lines, lh, fits = false;
  for (size = 70; size >= 30; size -= 2) {
    c.font = size + 'px ' + QFONT; lines = wrap(c, text, maxW); lh = size * 1.95;
    if (lines.length * lh <= maxH) { fits = true; break; }
  }
  var y0 = areaTop + (maxH - lines.length * lh) / 2 + lh / 2;
  lines.forEach(function (ln, i) { c.fillText(ln, W / 2, y0 + i * lh); });
  c.font = '600 40px ' + UFONT; c.fillStyle = st.accent; c.fillText(ref, W / 2, bottom - 78);
  return fits;
}
function openShare(s, a) {
  shareState = { s: s, a: a, style: store.get('shStyle', 'night'), fmt: store.get('shFmt', 'story') };
  var m = $('#modal'); m.className = 'modal';
  function chip(act, key, label, dot, pressed) {
    return '<button type="button" class="chip" data-act="' + act + '" data-k="' + key + '" aria-pressed="' + pressed + '">' +
      (dot ? '<i style="background:' + dot + '"></i>' : '') + label + '</button>';
  }
  m.innerHTML = '<div class="mhead"><h2>شارك كصورة</h2><button type="button" class="ibtn glass" data-act="closemodal" aria-label="إغلاق">' + ic('x', 22) + '</button></div>' +
    '<div class="preview"><canvas id="cv" aria-label="معاينة الصورة"></canvas></div>' +
    '<div class="group"><div class="gl">الخلفية</div><div class="chips" id="chStyle">' +
    chip('style', 'night', 'ليل', STYLES.night.dot, false) + chip('style', 'dawn', 'فجر', STYLES.dawn.dot, false) + chip('style', 'paper', 'ورق', STYLES.paper.dot, false) + '</div></div>' +
    '<div class="group"><div class="gl">الشكل</div><div class="chips" id="chFmt">' +
    chip('fmt', 'story', 'قصة وحالة واتساب', '', false) + chip('fmt', 'square', 'مربع', '', false) + '</div></div>' +
    '<div class="mact"><button type="button" class="go" data-act="doshare">' + ic('send', 22) + 'مشاركة</button>' +
    '<button type="button" class="sv glass" data-act="dosave">' + ic('download', 22) + 'حفظ</button></div>';
  m.hidden = false;
  renderShare();
}
function renderShare() {
  var cv = $('#cv'), st = shareState;
  var text = ayahText(st.s, st.a), ref = refName(st.s, st.a);
  var fontReady = (document.fonts && document.fonts.load) ? document.fonts.load('30px QuranFont').catch(function () {}) : Promise.resolve();
  fontReady.then(function () {
    var fits = drawCard(cv, text, ref, st.style, st.fmt);
    if (!fits && st.fmt === 'square') {
      st.fmt = 'story'; toast('الآية طويلة، تم اختيار شكل القصة');
      drawCard(cv, text, ref, st.style, st.fmt);
    }
    var b = document.querySelectorAll('#chStyle .chip'), i;
    for (i = 0; i < b.length; i++) b[i].setAttribute('aria-pressed', b[i].getAttribute('data-k') === st.style ? 'true' : 'false');
    b = document.querySelectorAll('#chFmt .chip');
    for (i = 0; i < b.length; i++) b[i].setAttribute('aria-pressed', b[i].getAttribute('data-k') === st.fmt ? 'true' : 'false');
  });
}
function pngBase64() { return $('#cv').toDataURL('image/png').split(',')[1]; }
function closeModal() { $('#modal').hidden = true; }


/* ================= الصوت ================= */
var CDN = 'https://cdn.islamic.app/quran/';
var ARN = { 'ar.alafasy': 'مشاري العفاسي', 'ar.abdurrahmaansudais': 'عبد الرحمن السديس', 'ar.saadalghamdi': 'سعد الغامدي' };
var FALLBACK = [
  { id: 'ar.alafasy', name: 'مشاري العفاسي', ayah: true, surah: true },
  { id: 'ar.abdurrahmaansudais', name: 'عبد الرحمن السديس', ayah: true, surah: false },
  { id: 'ar.saadalghamdi', name: 'سعد الغامدي', ayah: false, surah: true }
];
var RECS = FALLBACK, LOCAL = {}, DL = {}, confirmCb = null;
var P = { a: null, mode: '', s: 0, ay: 0, on: false, rid: '', rowS: 0 };

function player() {
  if (!P.a) {
    var a = new Audio();
    a.preload = 'auto';
    a.addEventListener('timeupdate', updateTime);
    a.addEventListener('loadedmetadata', updateTime);
    a.addEventListener('play', function () { P.on = true; syncUI(); });
    a.addEventListener('pause', function () { P.on = false; syncUI(); });
    a.addEventListener('ended', onEnded);
    a.addEventListener('error', onAudioErr);
    P.a = a;
  }
  return P.a;
}
function recById(id) { for (var i = 0; i < RECS.length; i++) if (RECS[i].id === id) return RECS[i]; return null; }
function curRec() { return recById(store.get('rid', 'ar.alafasy')) || RECS[0]; }
function recKind(r) { return r.surah && r.ayah ? 'سور كاملة وآية بآية' : (r.surah ? 'سور كاملة' : 'آية بآية'); }
function fname(rid, s) { return rid + '_' + s + '.mp3'; }
function fmt(t) {
  if (!isFinite(t) || t < 0) t = 0;
  var m = Math.floor(t / 60), sec = Math.floor(t % 60);
  return AR(m) + ':' + AR(sec < 10 ? '0' + sec : sec);
}
function loadReciters() {
  return fetch('https://api.islamic.app/v1/audio/reciters').then(function (r) { return r.json(); }).then(function (j) {
    var arr = j && (j.data || j);
    if (!Array.isArray(arr)) throw new Error('shape');
    var out = [];
    arr.forEach(function (r) {
      if (!r || !/^[A-Za-z0-9][A-Za-z0-9._-]{0,60}$/.test(r.identifier || '')) return;
      if (r.language !== 'ar' || r.format !== 'audio' || r.type === 'translation') return;
      var lv = r.audioLevels || [], ay = lv.indexOf('ayah') !== -1, su = lv.indexOf('surah') !== -1;
      if (!ay && !su) return;
      var nm = ARN[r.identifier] || (/[\u0600-\u06FF]/.test(r.name || '') ? r.name : (r.englishName || r.identifier));
      out.push({ id: r.identifier, name: nm, ayah: ay, surah: su });
    });
    if (out.length) { RECS = out; store.set('recs', out); if (state.tab === 'audio') renderAudio(); }
  }).catch(function () {});
}
function refreshLocal() {
  LOCAL = {};
  try {
    if (window.Android && Android.listAudio) JSON.parse(Android.listAudio()).forEach(function (n) { LOCAL[n] = true; });
  } catch (e) {}
}

/* التشغيل */
function startSrc(src, mode, s, ay) {
  var a = player(), r = curRec();
  P.mode = mode; P.s = s; P.ay = ay; P.rid = r ? r.id : '';
  a.src = src;
  var pr = a.play();
  if (pr && pr.catch) pr.catch(onAudioErr);
  P.on = true;
  syncUI();
}
function surahSrc(r, s) {
  var n = fname(r.id, s);
  return LOCAL[n] ? 'https://appassets.androidplatform.net/audio/' + n : CDN + 'audio-surah/' + r.id + '/' + s + '.mp3';
}
function playSurah(s) {
  var r = curRec();
  if (!r) return;
  if (r.surah) startSrc(surahSrc(r, s), 'surah', s, 0);
  else if (r.ayah) playAyah(s, 1);
}
function playAyah(s, a) {
  var r = curRec();
  if (!r || !r.ayah) { toast('هذا القارئ متاح بسور كاملة فقط. اختر قارئًا آخر من تبويب الصوت'); return; }
  startSrc(CDN + 'audio/' + r.id + '/' + (flatIndex(s, a) + 1) + '.mp3', 'ayah', s, a);
}
function toggleSurah(s) {
  if (P.mode && P.s === s) togglePlay(); else playSurah(s);
}
function togglePlay() {
  var a = player();
  if (!P.mode) return;
  if (a.paused) { var pr = a.play(); if (pr && pr.catch) pr.catch(onAudioErr); } else { a.pause(); }
}
function step(d) {
  if (!P.mode) return;
  if (P.mode === 'surah') {
    var t = P.s + d;
    if (t >= 1 && t <= 114) playSurah(t);
    return;
  }
  var s2 = P.s, a2 = P.ay + d;
  if (a2 < 1) { if (s2 <= 1) return; s2--; a2 = AY[s2].length; }
  else if (a2 > AY[s2].length) { if (s2 >= 114) return; s2++; a2 = 1; }
  playAyah(s2, a2);
}
function onEnded() {
  if (P.mode === 'ayah') {
    if (P.ay < AY[P.s].length) playAyah(P.s, P.ay + 1);
    else { P.on = false; syncUI(); }
  } else { P.on = false; syncUI(); }
}
function onAudioErr() {
  var a = player(), r = recById(P.rid);
  if (P.mode === 'surah' && r && a.src.indexOf('appassets') !== -1) {
    startSrc(CDN + 'audio-surah/' + r.id + '/' + P.s + '.mp3', 'surah', P.s, 0);
    return;
  }
  toast('تعذّر تشغيل الصوت. تأكد من الإنترنت أو جرّب قارئًا آخر');
  P.on = false; syncUI();
}
function stopAll() {
  var a = player(), old = P.s;
  a.pause();
  a.removeAttribute('src');
  try { a.load(); } catch (e) {}
  P.mode = ''; P.on = false; P.s = 0; P.ay = 0;
  syncUI();
  if (old && state.tab === 'audio') refreshRow(old);
}
function listenHere() {
  var s = state.surah, a = state.sel;
  if (!s || !a) return;
  playAyah(s, a);
  if (P.mode === 'ayah') closeSheet();
}

/* المشغّل المصغّر */
function buildMini() {
  $('#mini').innerHTML =
    '<div class="mtop"><div class="mtxt"><b id="mt"></b><small id="ms"></small></div>' +
    '<button type="button" class="mx" data-act="mclose" aria-label="إيقاف وإغلاق">' + ic('x', 20) + '</button></div>' +
    '<div class="mctl" dir="ltr"><button type="button" class="mb" data-act="mprev" aria-label="السابق">' + ic('skipb', 22, 'currentColor') + '</button>' +
    '<button type="button" class="mb mplay" id="mplay" data-act="mplay" aria-label="تشغيل أو إيقاف"></button>' +
    '<button type="button" class="mb" data-act="mnext" aria-label="التالي">' + ic('skipf', 22, 'currentColor') + '</button>' +
    '<input id="mseek" type="range" min="0" max="1000" value="0" aria-label="موضع التشغيل"><span id="mtime" class="mtime">٠:٠٠ / —</span></div>';
}
function updateTime() {
  var a = player(), sk = $('#mseek'), tm = $('#mtime');
  if (!sk || !tm) return;
  var d = a.duration, ok = d && isFinite(d);
  sk.value = ok ? Math.round(a.currentTime / d * 1000) : 0;
  tm.textContent = fmt(a.currentTime) + ' / ' + (ok ? fmt(d) : '—');
}
function syncUI() {
  var m = $('#mini');
  if (!P.mode) {
    m.hidden = true; document.body.classList.remove('has-mini');
  } else {
    m.hidden = false; document.body.classList.add('has-mini');
    var r = recById(P.rid);
    $('#mt').textContent = 'سورة ' + SURAHS[P.s - 1] + (P.mode === 'ayah' ? ' — الآية ' + AR(P.ay) : '');
    $('#ms').textContent = r ? r.name : '';
    $('#mplay').innerHTML = P.on ? ic('pause', 26) : ic('play', 26, 'currentColor');
  }
  markPlaying();
  if (state.tab === 'audio') {
    if (P.rowS && P.rowS !== P.s) refreshRow(P.rowS);
    if (P.s) refreshRow(P.s);
    P.rowS = P.s;
  }
}
function markPlaying() {
  var old = document.querySelectorAll('#mus .ay.playing'), i;
  for (i = 0; i < old.length; i++) old[i].classList.remove('playing');
  if (P.mode === 'ayah' && state.surah === P.s && $('#reader').classList.contains('open')) {
    var el = $('#mus .ay[data-a="' + P.ay + '"]');
    if (el) {
      el.classList.add('playing');
      var rc = el.getBoundingClientRect();
      if (rc.top < 110 || rc.bottom > window.innerHeight - 190) el.scrollIntoView({ block: 'center' });
    }
  }
}

/* شاشة الصوت */
function rowHTML(s) {
  var r = curRec(), n = fname(r.id, s), c = AY[s].length, playing = P.mode && P.s === s, stat = '', dl = '';
  if (r.surah) {
    if (DL[n] !== undefined) {
      stat = ' — جارٍ التنزيل';
      dl = '<button type="button" class="ibtn lite" data-act="scancel" data-s="' + s + '" aria-label="إلغاء التنزيل"><span class="pct">' + AR(DL[n]) + '٪</span></button>';
    } else if (LOCAL[n]) {
      stat = ' — محمّلة';
      dl = '<button type="button" class="ibtn lite" data-act="sdel" data-s="' + s + '" aria-label="حذف التنزيل">' + ic('trash', 22) + '</button>';
    } else {
      dl = '<button type="button" class="ibtn lite" data-act="sdl" data-s="' + s + '" aria-label="تنزيل السورة">' + ic('download', 22) + '</button>';
    }
  }
  var on = playing && P.on;
  return '<div class="row lite" data-row="' + s + '">' + star(s) +
    '<div class="grow"><div class="nm">سورة ' + SURAHS[s - 1] + '</div><div class="ct">' + AR(c) + ' ' + ayahWord(c) + stat + '</div></div>' +
    '<button type="button" class="ibtn lite" data-act="splay" data-s="' + s + '" aria-label="تشغيل سورة ' + SURAHS[s - 1] + '">' + ic(on ? 'pause' : 'play', 22, on ? 'none' : 'currentColor') + '</button>' + dl + '</div>';
}
function refreshRow(s) {
  var el = $('#audio [data-row="' + s + '"]');
  if (el) el.outerHTML = rowHTML(s);
}
function renderAudio() {
  var r = curRec(), h = '<h2>الصوت</h2>' +
    '<button type="button" class="recbtn glass" data-act="recs"><span class="sub">القارئ</span><b>' + esc(r.name) + '</b>' + ic('chev', 22) + '</button>' +
    '<p class="count">' + recKind(r) + (r.surah ? '' : ' — التنزيل غير متاح لهذا القارئ') + '</p><div class="list">';
  for (var s = 1; s <= 114; s++) h += rowHTML(s);
  $('#audio').innerHTML = h + '</div>';
}
function openRecs() {
  var m = $('#modal'), cur = curRec().id;
  m.className = 'modal';
  var h = '<div class="mhead"><h2>اختر القارئ</h2><button type="button" class="ibtn glass" data-act="closemodal" aria-label="إغلاق">' + ic('x', 22) + '</button></div><div class="list">';
  RECS.forEach(function (r) {
    h += '<button type="button" class="row lite" data-act="pickrec" data-id="' + esc(r.id) + '"><div class="grow"><div class="nm" style="font-size:20px">' +
      esc(r.name) + '</div><div class="ct">' + recKind(r) + '</div></div>' + (r.id === cur ? ic('check', 24) : '') + '</button>';
  });
  m.innerHTML = h + '</div>';
  m.hidden = false;
}
function confirmBox(msg, label, cb) {
  confirmCb = cb;
  var m = $('#modal');
  m.className = 'modal center';
  m.innerHTML = '<div class="dlg glass"><p>' + esc(msg) + '</p><div class="chips"><button type="button" class="chip" data-act="closemodal">إلغاء</button>' +
    '<button type="button" class="chip warn" data-act="confirmyes">' + esc(label) + '</button></div></div>';
  m.hidden = false;
}

/* التنزيل */
function startDl(s) {
  var r = curRec(), n = fname(r.id, s);
  if (!r.surah) { toast('التنزيل متاح لتلاوات السور الكاملة فقط'); return; }
  if (!(window.Android && Android.download)) { toast('التنزيل متاح داخل التطبيق'); return; }
  DL[n] = 0; refreshRow(s);
  Android.download(CDN + 'audio-surah/' + r.id + '/' + s + '.mp3', n);
}
function cancelDl(s) {
  var r = curRec();
  if (window.Android && Android.cancelDownload) Android.cancelDownload(fname(r.id, s));
}
function askDel(s) {
  var r = curRec(), n = fname(r.id, s);
  confirmBox('حذف تلاوة سورة ' + SURAHS[s - 1] + ' المحمّلة من الجهاز؟', 'حذف', function () {
    if (window.Android && Android.deleteAudio) Android.deleteAudio(n);
    delete LOCAL[n]; refreshRow(s); toast('تم الحذف');
  });
}
window.onDownload = function (name, pct, st) {
  var i = name.lastIndexOf('_'), s = +name.slice(i + 1).replace('.mp3', '');
  if (st === 'run') { DL[name] = pct; }
  else {
    delete DL[name];
    if (st === 'done') { LOCAL[name] = true; toast('تم تنزيل سورة ' + SURAHS[s - 1]); }
    else if (st === 'err') { toast('تعذّر التنزيل. تحقق من الاتصال'); }
  }
  if (state.tab === 'audio') refreshRow(s);
};

/* ================= عن التطبيق ================= */
function openAbout() {
  var m = $('#modal'); m.className = 'modal';
  m.innerHTML = '<div class="mhead"><h2>عن التطبيق</h2><button type="button" class="ibtn glass" data-act="closemodal" aria-label="إغلاق">' + ic('x', 22) + '</button></div>' +
    '<div class="about"><h3>نص القرآن</h3><p>رواية حفص عن عاصم من مشروع تنزيل (Tanzil Project) — tanzil.net — النص بالرسم العثماني ويُعرض كما هو من غير أي تعديل. الترخيص: CC BY 3.0.</p>' +
    '<h3>التفسير والصفحات والأجزاء</h3><p>مأخوذة من بيانات مضمّنة مع التطبيق، ولم تُراجَع مصادرها بعد. راجعها قبل أي نشر عام.</p>' +
    '<h3>الصوت</h3><p>التلاوات تُجلب من cdn.islamic.app وتحتاج إنترنت للتشغيل المباشر، ويمكن تنزيل السور للاستماع بلا إنترنت. شروط استخدام التلاوات لم تُراجَع بعد.</p>' +
    '<h3>نسخة تجريبية</h3><p>الروايات الأخرى وألوان التجويد قيد الإضافة. قراءة النص والبحث والتفسير تعمل بلا إنترنت.</p></div>';
  m.hidden = false;
}

/* ================= أدوات واجهة ================= */
var toastTimer = null;
window.toast = function (msg) {
  var t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('show'); }, 2000);
};
function toast(m) { window.toast(m); }
window.handleBack = function () {
  if (!$('#modal').hidden) { closeModal(); return true; }
  var pop = $('#aa');
  if (pop && !pop.hidden) { pop.hidden = true; return true; }
  if (!$('#sheet').hidden) {
    if ($('#sheet .tafsir')) { renderSheet(); return true; }
    closeSheet(); return true;
  }
  if ($('#reader').classList.contains('open')) { closeReader(); return true; }
  if (state.tab !== 'home') { showTab('home'); return true; }
  return false;
};

document.addEventListener('click', function (e) {
  var ay = e.target.closest ? e.target.closest('.ay') : null;
  if (ay && $('#reader').classList.contains('open')) {
    var a = +ay.getAttribute('data-a');
    if (state.sel === a) closeSheet(); else selectAyah(a);
    return;
  }
  var b = e.target.closest ? e.target.closest('[data-act]') : null;
  var aa = $('#aa');
  if (aa && !aa.hidden && !(b && (b.getAttribute('data-act') === 'aa' || aa.contains(b)))) aa.hidden = true;
  if (!b) return;
  var act = b.getAttribute('data-act'), s = +b.getAttribute('data-s'), x = +b.getAttribute('data-a') || 0;
  switch (act) {
    case 'tab': showTab(b.getAttribute('data-tab')); if (b.getAttribute('data-tab') === 'search') setTimeout(function () { var q = $('#q'); if (q) q.focus(); }, 80); break;
    case 'open': openReader(s, x, b.getAttribute('data-pick') === '1'); break;
    case 'nav': openReader(s, 0); break;
    case 'close': closeReader(); break;
    case 'about': openAbout(); break;
    case 'closemodal': closeModal(); break;
    case 'closesheet': closeSheet(); break;
    case 'tback': renderSheet(); break;
    case 'aa': $('#aa').hidden = !$('#aa').hidden; break;
    case 'fs': state.fs += +b.getAttribute('data-d'); applyFs(); break;
    case 'theme': setTheme(state.theme === 'night' ? 'paper' : 'night'); break;
    case 'copy':
      if (window.Android && Android.copyText) Android.copyText(shareTextOf(state.surah, state.sel));
      else if (navigator.clipboard) navigator.clipboard.writeText(shareTextOf(state.surah, state.sel));
      toast('تم النسخ'); break;
    case 'sharetext':
      if (window.Android && Android.shareText) Android.shareText(shareTextOf(state.surah, state.sel));
      else if (navigator.share) navigator.share({ text: shareTextOf(state.surah, state.sel) });
      break;
    case 'shareimg': openShare(state.surah, state.sel); break;
    case 'bm': toggleBm(); break;
    case 'tafsir': showTafsir(); break;
    case 'recs': openRecs(); break;
    case 'pickrec': store.set('rid', b.getAttribute('data-id')); closeModal(); if (state.tab === 'audio') renderAudio(); break;
    case 'splay': toggleSurah(s); break;
    case 'sdl': startDl(s); break;
    case 'scancel': cancelDl(s); break;
    case 'sdel': askDel(s); break;
    case 'mplay': togglePlay(); break;
    case 'mprev': step(-1); break;
    case 'mnext': step(1); break;
    case 'mclose': stopAll(); break;
    case 'listen': listenHere(); break;
    case 'confirmyes': closeModal(); if (confirmCb) { var cf = confirmCb; confirmCb = null; cf(); } break;
    case 'style': shareState.style = b.getAttribute('data-k'); store.set('shStyle', shareState.style); renderShare(); break;
    case 'fmt': shareState.fmt = b.getAttribute('data-k'); store.set('shFmt', shareState.fmt); renderShare(); break;
    case 'doshare':
      if (window.Android && Android.shareImage) Android.shareImage(pngBase64());
      else { var l = document.createElement('a'); l.href = $('#cv').toDataURL('image/png'); l.download = 'ayah.png'; l.click(); }
      break;
    case 'dosave':
      if (window.Android && Android.saveImage) Android.saveImage(pngBase64()); else toast('الحفظ متاح داخل التطبيق');
      break;
  }
});
document.addEventListener('input', function (e) {
  if (e.target && e.target.id === 'mseek') {
    var au = player();
    if (au.duration && isFinite(au.duration)) au.currentTime = (+e.target.value / 1000) * au.duration;
    return;
  }
  if (e.target && e.target.id === 'q') {
    var v = e.target.value; clearTimeout(searchTimer);
    searchTimer = setTimeout(function () { doSearch(v); }, 200);
  }
});

/* ================= البدء ================= */
function start() {
  document.body.setAttribute('data-theme', state.theme);
  if (window.Android && Android.setBars) Android.setBars(state.theme === 'paper');
  RECS = store.get('recs', null) || FALLBACK;
  refreshLocal(); buildMini(); loadReciters();
  load().then(function () { showTab('home'); }).catch(function () {
    $('#home').innerHTML = '<p class="err">تعذّر تحميل نص القرآن أو أنه غير مكتمل.<br>أعد تثبيت التطبيق، وإذا استمرت المشكلة أبلغ المطوّر.</p>';
    renderTabs();
  });
}
start();
})();
