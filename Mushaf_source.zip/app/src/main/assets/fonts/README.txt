ضع هنا ملف الخط باسم quran.ttf (مثلا Amiri Quran) ليستخدم تلقائيا.
