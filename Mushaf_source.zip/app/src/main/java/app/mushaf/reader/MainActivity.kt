package app.mushaf.reader

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.core.content.FileProvider
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private val cancelled = ConcurrentHashMap<String, Boolean>()

    private val audioDir: File
        get() {
            val d = File(filesDir, "audio")
            d.mkdirs()
            return d
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = FrameLayout(this)
        root.fitsSystemWindows = true
        web = WebView(this)
        web.setBackgroundColor(Color.TRANSPARENT)
        root.addView(
            web,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)
        applyBars(false)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.textZoom = 100
        s.mediaPlaybackRequiresUserGesture = false

        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val req = request ?: return null
                val uri = req.url
                if (uri.host == HOST && (uri.path ?: "").startsWith("/audio/")) {
                    return serveAudio(req)
                }
                return loader.shouldInterceptRequest(uri)
            }
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("https://$HOST/assets/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        web.evaluateJavascript("window.handleBack ? window.handleBack() : false") { r ->
            if (r != "true") finish()
        }
    }

    @Suppress("DEPRECATION")
    private fun applyBars(light: Boolean) {
        val c = Color.parseColor(if (light) LIGHT else DARK)
        window.statusBarColor = c
        window.navigationBarColor = c
        root.setBackgroundColor(c)
        var flags = 0
        if (light) {
            flags = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = flags
    }

    private fun jsToast(msg: String) {
        runOnUiThread {
            web.evaluateJavascript(
                "window.toast && window.toast(" + JSONObject.quote(msg) + ")",
                null
            )
        }
    }

    private fun jsDownload(name: String, pct: Int, state: String) {
        runOnUiThread {
            web.evaluateJavascript(
                "window.onDownload && window.onDownload(" + JSONObject.quote(name) + "," + pct +
                    "," + JSONObject.quote(state) + ")",
                null
            )
        }
    }

    /** يخدم ملفات الصوت المحمّلة من التخزين الداخلي مع دعم Range للتقديم والتأخير. */
    private fun serveAudio(request: WebResourceRequest): WebResourceResponse {
        val name = request.url.lastPathSegment ?: ""
        val file = File(audioDir, name)
        if (!NAME_RE.matches(name) || !file.isFile) {
            return WebResourceResponse(
                "text/plain", "utf-8", 404, "Not Found",
                HashMap<String, String>(), ByteArrayInputStream(ByteArray(0))
            )
        }
        val len = file.length()
        var start = 0L
        var end = len - 1
        var partial = false
        val range = request.requestHeaders["Range"] ?: request.requestHeaders["range"]
        if (range != null && range.startsWith("bytes=")) {
            val p = range.substring(6).split("-")
            start = p.getOrNull(0)?.toLongOrNull() ?: 0L
            end = p.getOrNull(1)?.toLongOrNull() ?: (len - 1)
            if (end >= len) end = len - 1
            if (start > end) {
                start = 0L
                end = len - 1
            } else {
                partial = true
            }
        }
        val raf = RandomAccessFile(file, "r")
        raf.seek(start)
        val headers = HashMap<String, String>()
        headers["Accept-Ranges"] = "bytes"
        headers["Content-Length"] = (end - start + 1).toString()
        if (partial) headers["Content-Range"] = "bytes $start-$end/$len"
        return WebResourceResponse(
            "audio/mpeg", null,
            if (partial) 206 else 200,
            if (partial) "Partial Content" else "OK",
            headers,
            RangeStream(raf, end - start + 1)
        )
    }

    inner class Bridge {

        @JavascriptInterface
        fun shareText(text: String) {
            runOnUiThread {
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                startActivity(Intent.createChooser(i, "مشاركة الآية"))
            }
        }

        @JavascriptInterface
        fun copyText(text: String) {
            runOnUiThread {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("ayah", text))
            }
        }

        @JavascriptInterface
        fun shareImage(b64: String) {
            try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                val dir = File(cacheDir, "shared")
                dir.mkdirs()
                dir.listFiles()?.forEach { it.delete() }
                val f = File(dir, "ayah_" + System.currentTimeMillis() + ".png")
                f.writeBytes(bytes)
                val uri = FileProvider.getUriForFile(
                    this@MainActivity, "$packageName.fileprovider", f
                )
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "image/png"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                runOnUiThread { startActivity(Intent.createChooser(i, "مشاركة الآية")) }
            } catch (e: Exception) {
                jsToast("تعذّرت المشاركة")
            }
        }

        @JavascriptInterface
        fun saveImage(b64: String) {
            try {
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "ayah_" + System.currentTimeMillis() + ".png")
                        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Mushaf")
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    if (uri != null) {
                        contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        jsToast("تم الحفظ في المعرض")
                    } else {
                        jsToast("تعذّر الحفظ")
                    }
                } else {
                    jsToast("الحفظ يحتاج أندرويد 10 أو أحدث، استخدم المشاركة")
                }
            } catch (e: Exception) {
                jsToast("تعذّر الحفظ")
            }
        }

        @JavascriptInterface
        fun setBars(light: Boolean) {
            runOnUiThread { applyBars(light) }
        }

        @JavascriptInterface
        fun listAudio(): String {
            val names = audioDir.listFiles()
                ?.filter { it.isFile && NAME_RE.matches(it.name) }
                ?.map { "\"" + it.name + "\"" }
                ?: emptyList()
            return names.joinToString(",", "[", "]")
        }

        @JavascriptInterface
        fun deleteAudio(name: String) {
            if (NAME_RE.matches(name)) File(audioDir, name).delete()
        }

        @JavascriptInterface
        fun cancelDownload(name: String) {
            cancelled[name] = true
        }

        @JavascriptInterface
        fun download(url: String, name: String) {
            val okUrl = url.startsWith("https://cdn.islamic.app/") ||
                url.startsWith("https://cdn.islamic.network/")
            if (!NAME_RE.matches(name) || !okUrl) {
                jsDownload(name, 0, "err")
                return
            }
            cancelled.remove(name)
            Thread {
                var conn: HttpURLConnection? = null
                val part = File(audioDir, "$name.part")
                try {
                    conn = URL(url).openConnection() as HttpURLConnection
                    conn.connectTimeout = 15000
                    conn.readTimeout = 20000
                    conn.instanceFollowRedirects = true
                    if (conn.responseCode != 200) throw IOException("HTTP " + conn.responseCode)
                    val total = conn.contentLengthLong
                    conn.inputStream.use { input ->
                        FileOutputStream(part).use { out ->
                            val buf = ByteArray(32 * 1024)
                            var done = 0L
                            var last = -1
                            while (true) {
                                if (cancelled[name] == true) throw IOException("cancelled")
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                if (total > 0) {
                                    val p = (done * 100 / total).toInt()
                                    if (p != last) {
                                        last = p
                                        jsDownload(name, p, "run")
                                    }
                                }
                            }
                        }
                    }
                    if (!part.renameTo(File(audioDir, name))) throw IOException("rename failed")
                    jsDownload(name, 100, "done")
                } catch (e: Exception) {
                    part.delete()
                    jsDownload(name, 0, if (cancelled[name] == true) "cancel" else "err")
                } finally {
                    conn?.disconnect()
                    cancelled.remove(name)
                }
            }.start()
        }
    }

    private class RangeStream(
        private val raf: RandomAccessFile,
        private var remaining: Long
    ) : InputStream() {
        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = raf.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = raf.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n.toLong()
            return n
        }

        override fun close() {
            raf.close()
        }
    }

    companion object {
        const val DARK = "#06161A"
        const val LIGHT = "#F5F0E2"
        const val HOST = "appassets.androidplatform.net"
        val NAME_RE = Regex("[A-Za-z0-9._-]{1,120}\\.mp3")
    }
}
