package com.alsadq.quran

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.Color as AColor
import android.os.Bundle
import android.media.MediaPlayer
import android.app.DownloadManager
import android.net.Uri
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import org.json.JSONArray

private val Deep = Color(0xFF071B22)
private val Emerald = Color(0xFF0D766B)
private val Gold = Color(0xFFE8CB82)
private val Glass = Color(0xFF16353C)

data class Surah(val id:Int,val number:Int,val name:String,val english:String,val type:String)
data class Ayah(val id:Int,val number:Int,val text:String,val surah:Int,val inSurah:Int,val tafsir:String,val tajweed:String)
data class Reciter(val id:String,val name:String)

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { QuranApp() } }
}

@Composable fun QuranApp() {
 val ctx= LocalContext.current
 val data= remember { loadData(ctx) }
 var page by remember { mutableStateOf("الرئيسية") }
 var selectedSurah by remember { mutableStateOf<Surah?>(null) }
 var showTafsir by remember { mutableStateOf(false) }
 var showTajweed by remember { mutableStateOf(false) }
 var query by remember { mutableStateOf("") }
 var reciter by remember { mutableStateOf(data.third.firstOrNull()?.id ?: "ar.alafasy") }
 var currentAyah by remember { mutableStateOf<Ayah?>(null) }
 var playing by remember { mutableStateOf(false) }
 var player by remember { mutableStateOf<MediaPlayer?>(null) }
 DisposableEffect(Unit) { onDispose { player?.release() } }
 MaterialTheme(colorScheme=darkColorScheme(primary=Emerald,secondary=Gold,background=Deep,surface=Glass)) {
  Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF16454A),Deep,Color(0xFF041116))))) {
   Column(Modifier.fillMaxSize().padding(horizontal=16.dp)) {
    Row(Modifier.fillMaxWidth().padding(top=18.dp,bottom=14.dp),verticalAlignment=Alignment.CenterVertically) {
     Column(Modifier.weight(1f)) { Text("رِفْقَةُ القُرْآن",color=Gold,fontSize=13.sp); Text("القرآن الكريم",fontSize=27.sp,fontWeight=FontWeight.Bold,color=Color.White); Text("اقرأ • تدبّر • استمع",color=Color.LightGray,fontSize=13.sp) }
     Surface(color=Color.White.copy(alpha=.10f),shape=RoundedCornerShape(18.dp)){ Box(Modifier.size(54.dp),contentAlignment=Alignment.Center){ Icon(Icons.Default.MenuBook,null,tint=Gold,modifier=Modifier.size(32.dp)) } }
    }
    when {
     selectedSurah != null -> {
      Row(verticalAlignment=Alignment.CenterVertically) { IconButton(onClick={selectedSurah=null;showTafsir=false;showTajweed=false}){Icon(Icons.Default.ArrowForward,null,tint=Color.White)}; Column { Text(selectedSurah!!.name,color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold); Text("رواية حفص • ${selectedSurah!!.type}",color=Gold,fontSize=12.sp) } }
      Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.padding(vertical=8.dp)) { FilterChip(showTajweed,{showTajweed=!showTajweed},label={Text("التجويد")},leadingIcon={Icon(Icons.Default.AutoAwesome,null)}); FilterChip(showTafsir,{showTafsir=!showTafsir},label={Text("التفسير")},leadingIcon={Icon(Icons.Default.MenuBook,null)}) }
      val verses=data.second.filter{it.surah==selectedSurah!!.id}
      LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=16.dp),modifier=Modifier.weight(1f)) {
       items(verses){ a -> Surface(color=Color.White.copy(alpha=.075f),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
        Text(if(showTajweed) stripTajweed(a.tajweed) else a.text,color=Color(0xFFFFF4D9),fontSize=24.sp,lineHeight=42.sp,textAlign=TextAlign.Right,modifier=Modifier.fillMaxWidth())
        Row(verticalAlignment=Alignment.CenterVertically) { Text("۞ ${a.inSurah}",color=Gold,fontSize=12.sp,modifier=Modifier.weight(1f)); IconButton(onClick={shareText(ctx,"${a.text}\n[${selectedSurah!!.name}: ${a.inSurah}]")}){Icon(Icons.Default.Share,"مشاركة",tint=Gold)}; IconButton(onClick={currentAyah=a; playAyah(a,reciter,player,{player=it},{playing=it})}){Icon(Icons.Default.PlayArrow,"استمع",tint=Gold)} }
        if(showTafsir && a.tafsir.isNotBlank()) { Divider(color=Gold.copy(alpha=.35f)); Text("التفسير الميسر",color=Gold,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=8.dp)); Text(a.tafsir,color=Color(0xFFD6E2E0),fontSize=14.sp,lineHeight=24.sp,modifier=Modifier.padding(top=5.dp)) }
       } } }
      }
     }
     page=="الخلفيات الإسلامية" -> {
      Text("الخلفيات الإسلامية",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold)
      Text("خلفيات إسلامية وروحانية — افتح الصورة لتنزيلها أو مشاركتها من المتصفح.",color=Color.LightGray,fontSize=13.sp,modifier=Modifier.padding(vertical=8.dp))
      val wallpapers = listOf(
       "مسجد وقت الغروب" to "https://images.unsplash.com/photo-1564769625905-50e93615e769?w=1200",
       "قبة مسجد وزخارف" to "https://images.unsplash.com/photo-1519817650390-64a93db51149?w=1200",
       "سماء ليلية هادئة" to "https://images.unsplash.com/photo-1470252649378-9c29740c9fa8?w=1200",
       "طبيعة خضراء" to "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=1200",
       "عمارة إسلامية" to "https://images.unsplash.com/photo-1548013146-72479768bada?w=1200",
       "ضوء الفجر" to "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?w=1200"
      )
      LazyColumn(modifier=Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(10.dp)) {
       items(wallpapers){ (title,url) -> Surface(color=Color.White.copy(alpha=.08f),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().clickable { try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_:Exception) {} }) {
        Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.Wallpaper,null,tint=Gold,modifier=Modifier.size(32.dp)); Spacer(Modifier.width(12.dp)); Text(title,color=Color.White,modifier=Modifier.weight(1f)); IconButton(onClick={downloadFile(ctx,url,"wallpaper_${wallpapers.indexOf(title to url)+1}.jpg","خلفيات إسلامية")}){Icon(Icons.Default.Download,"تنزيل الخلفية",tint=Gold)} }
       } }
      }
     }
     page=="المكتبة الصوتية" -> {
      Text("المكتبة الصوتية",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold)
      Text("اختار القارئ، ثم افتح سورة واضغط علامة التشغيل بجوار الآية.",color=Color.LightGray,fontSize=13.sp,modifier=Modifier.padding(vertical=8.dp))
      Text("القارئ",color=Gold,fontSize=14.sp)
      Row(horizontalArrangement=Arrangement.spacedBy(6.dp),modifier=Modifier.fillMaxWidth().padding(vertical=6.dp)) {
       data.third.take(4).forEach { r -> FilterChip(selected=reciter==r.id,onClick={reciter=r.id},label={Text(reciterArabic(r.name),fontSize=11.sp)}) }
      }
      Text("نزّل السورة للاستماع دون إنترنت",color=Color.LightGray,fontSize=13.sp,modifier=Modifier.padding(vertical=6.dp))
      LazyColumn(modifier=Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)) {
       items(data.first){ surah -> Surface(color=Color.White.copy(alpha=.075f),shape=RoundedCornerShape(15.dp),modifier=Modifier.fillMaxWidth()) {
        Row(Modifier.padding(start=13.dp,end=5.dp),verticalAlignment=Alignment.CenterVertically){ Icon(Icons.Default.MusicNote,null,tint=Gold); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f).clickable { selectedSurah=surah;page="المصحف" }) { Text(surah.name,color=Color.White,fontSize=15.sp); Text("${surah.number} • ${reciterArabic(data.third.find{it.id==reciter}?.name ?: reciter)}",color=Color.LightGray,fontSize=11.sp) }; IconButton(onClick={downloadFile(ctx,"https://cdn.islamic.network/quran/audio-surah/128/$reciter/${surah.number}.mp3","${surah.number}_${reciter}.mp3","تلاوات القرآن")}){Icon(Icons.Default.Download,"تنزيل ${surah.name}",tint=Gold)} }
       } }
      }
      currentAyah?.let { Text("آخر آية مختارة: ${it.text.take(65)}…",color=Gold,fontSize=13.sp) }
     }
     page=="التجويد" || page=="التفسير" -> {
      Text(page,color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold)
      Text(if(page=="التجويد") "افتح أي سورة ثم فعّل زر التجويد لعرض ترميز التجويد المتوفر في قاعدة البيانات." else "افتح أي سورة ثم فعّل زر التفسير لعرض التفسير الميسّر لكل آية.",color=Color(0xFFD6E2E0),fontSize=16.sp,lineHeight=27.sp,modifier=Modifier.padding(vertical=12.dp))
      Button(onClick={page="المصحف";selectedSurah=data.first.firstOrNull()}){Text("ابدأ من سورة الفاتحة")}
      Spacer(Modifier.weight(1f))
     }
     page=="مشاركة آية" -> {
      Text("مشاركة آية",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold)
      Text("اختار سورة ثم شارك أي آية كنص. إنشاء بطاقة صورة منسّقة متاح كخطوة تطوير لاحقة.",color=Color.LightGray,modifier=Modifier.padding(vertical=10.dp))
      LazyColumn(modifier=Modifier.weight(1f)){items(data.first){ s -> Text("${s.number}. ${s.name}",color=Color.White,modifier=Modifier.fillMaxWidth().clickable{selectedSurah=s;page="المصحف"}.padding(14.dp)) }}
     }
     else -> {
      Surface(color=Color.White.copy(alpha=.09f),shape=RoundedCornerShape(26.dp),modifier=Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){ Text("وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا",color=Gold,fontSize=25.sp,textAlign=TextAlign.Center); Text("مصحف حفص • تفسير • تجويد • تلاوات",color=Color.White,fontSize=14.sp,modifier=Modifier.padding(top=8.dp)); Text("${data.first.size} سورة  ·  ${data.second.size} آية",color=Color.LightGray,fontSize=12.sp,modifier=Modifier.padding(top=5.dp)) } }
      OutlinedButton(onClick={page="الخلفيات الإسلامية"},modifier=Modifier.fillMaxWidth().padding(top=10.dp),shape=RoundedCornerShape(16.dp)){Icon(Icons.Default.Wallpaper,null,tint=Gold);Spacer(Modifier.width(8.dp));Text("مكتبة الصور والخلفيات الإسلامية")}
      OutlinedTextField(value=query,onValueChange={query=it},modifier=Modifier.fillMaxWidth().padding(top=14.dp),placeholder={Text("ابحث عن سورة")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(16.dp))
      Text("السور",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp,bottom=8.dp))
      LazyColumn(modifier=Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp),contentPadding=PaddingValues(bottom=10.dp)){ items(data.first.filter{it.name.contains(query,true)||it.number.toString()==query}){ s -> Surface(color=Color.White.copy(alpha=.075f),shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth().clickable{selectedSurah=s;page="المصحف"}){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Surface(color=Emerald.copy(alpha=.45f),shape=RoundedCornerShape(12.dp)){Box(Modifier.size(40.dp),contentAlignment=Alignment.Center){Text(s.number.toString(),color=Gold,fontWeight=FontWeight.Bold)}}; Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(s.name,color=Color.White,fontSize=17.sp,fontWeight=FontWeight.SemiBold);Text(if(s.type.contains("med",true)||s.type.contains("مدن"))"مدنية" else "مكية",color=Color.LightGray,fontSize=12.sp)}; Text("${data.second.count{it.surah==s.id}} آية",color=Gold,fontSize=12.sp); Icon(Icons.Default.ChevronLeft,null,tint=Gold)} } } }
     }
    }
    NavigationBar(containerColor=Color(0xE6102930)){ val tabs=listOf("الرئيسية" to Icons.Default.Home,"المصحف" to Icons.Default.MenuBook,"التجويد" to Icons.Default.AutoAwesome,"التفسير" to Icons.Default.School,"المكتبة الصوتية" to Icons.Default.Headphones,"الخلفيات الإسلامية" to Icons.Default.Wallpaper)
     tabs.forEach{(label,ic)->NavigationBarItem(selected=page==label,onClick={page=label;if(label=="المصحف"&&selectedSurah==null)selectedSurah=data.first.firstOrNull()},icon={Icon(ic,null)},label={Text(when(label){"المكتبة الصوتية"->"الصوت";"الخلفيات الإسلامية"->"الخلفيات";else->label},fontSize=9.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Gold,selectedTextColor=Gold,indicatorColor=Emerald.copy(alpha=.35f),unselectedIconColor=Color.LightGray,unselectedTextColor=Color.LightGray))}
    }
   }
  }
 }
}

private fun loadData(ctx:android.content.Context):Triple<List<Surah>,List<Ayah>,List<Reciter>> {
 val raw=ctx.assets.open("quran_data.json").bufferedReader().use{it.readText()}; val root=JSONObject(raw)
 val ss=root.getJSONArray("surahs"); val surahs=(0 until ss.length()).map{val o=ss.getJSONObject(it);Surah(o.getInt("id"),o.getInt("number"),o.getString("name"),o.optString("english"),o.optString("type"))}
 val aa=root.getJSONArray("ayahs"); val ayahs=(0 until aa.length()).map{val o=aa.getJSONObject(it);Ayah(o.getInt("id"),o.getInt("n"),o.getString("text"),o.getInt("surah"),o.getInt("sn"),o.optString("tafsir"),o.optString("tajweed"))}
 val rr=root.getJSONArray("reciters"); val reciters=(0 until rr.length()).map{val o=rr.getJSONObject(it);Reciter(o.getString("id"),o.getString("name"))}
 return Triple(surahs,ayahs,reciters)
}
private fun stripTajweed(s:String):String = s.replace(Regex("\\[[^]]*]"),"").replace(Regex("[hl npq]:"),"").replace("[","").replace("]","").ifBlank{s}
private fun shareText(ctx:android.content.Context,text:String){val i=Intent(Intent.ACTION_SEND).apply{type="text/plain";putExtra(Intent.EXTRA_TEXT,text)};ctx.startActivity(Intent.createChooser(i,"مشاركة الآية"))}
private fun playAyah(a:Ayah,reciter:String,old:MediaPlayer?,onPlayer:(MediaPlayer?)->Unit,onPlaying:(Boolean)->Unit){try{old?.release();val mp=MediaPlayer();mp.setDataSource("https://cdn.alquran.cloud/media/audio/ayah/$reciter/${a.id}");mp.setOnPreparedListener{it.start();onPlaying(true)};mp.setOnCompletionListener{onPlaying(false);onPlayer(null);it.release()};mp.setOnErrorListener{p,_,_->onPlaying(false);onPlayer(null);p.release();true};mp.prepareAsync();onPlayer(mp)}catch(_:Exception){onPlaying(false)}}

private fun reciterArabic(name:String):String = when(name) {
 "Alafasy" -> "مشاري العفاسي"; "Husary" -> "محمود خليل الحصري"; "Husary (Mujawwad)" -> "الحصري مجوّد";
 "Abdul Basit" -> "عبدالباسط عبدالصمد"; "Abdul Samad" -> "عبدالباسط"; "Minshawi" -> "محمد صديق المنشاوي";
 "Minshawy (Mujawwad)" -> "المنشاوي مجوّد"; "Maher Al Muaiqly" -> "ماهر المعيقلي";
 "Abdurrahmaan As-Sudais" -> "عبدالرحمن السديس"; "Abu Bakr Ash-Shaatree" -> "أبو بكر الشاطري";
 "Ahmed ibn Ali al-Ajamy" -> "أحمد العجمي"; "Hudhaify" -> "علي الحذيفي"; else -> name
}

private fun downloadFile(ctx:android.content.Context,url:String,fileName:String,folder:String) {
 try {
  val request=DownloadManager.Request(Uri.parse(url))
   .setTitle(fileName).setDescription("جارٍ تنزيل $folder")
   .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
   .setAllowedOverMetered(true).setAllowedOverRoaming(false)
   .setDestinationInExternalFilesDir(ctx, if(fileName.endsWith(".mp3")) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_PICTURES, fileName)
  val manager=ctx.getSystemService(android.content.Context.DOWNLOAD_SERVICE) as DownloadManager
  manager.enqueue(request)
  Toast.makeText(ctx,"بدأ التنزيل — ستجد الملف في ملفات التطبيق",Toast.LENGTH_LONG).show()
 } catch (_:Exception) { Toast.makeText(ctx,"تعذر بدء التنزيل. تحقق من اتصال الإنترنت.",Toast.LENGTH_LONG).show() }
}
